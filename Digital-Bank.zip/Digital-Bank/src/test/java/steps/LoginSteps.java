package steps;


import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.util.concurrent.TimeUnit;

public class LoginSteps {

    private WebDriver driver;

    @Given("user navigates to Digital Bank")
    public void user_navigates_to_digital_bank() {
        WebDriverManager.firefoxdriver().setup();
        driver = new FirefoxDriver();

        driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        driver.get("https://dbank-qa.wedevx.co/bank");
    }

    @Then("user enters {string} correct username")
    public void user_enters_correct_username(String name) {
        WebElement userName = driver.findElement(By.id("username"));
        userName.sendKeys(name);
    }

    @Then("user enters {string} correct password")
    public void user_enters_correct_password(String userPassword) {
        WebElement password = driver.findElement(By.id("password"));
        password.sendKeys(userPassword);
    }

    @Then("user click on Remember Me chick box")
    public void user_click_on_remember_me_chick_box() {
        WebElement rememberMeClickBox = driver.findElement(By.id("remember-me"));
        rememberMeClickBox.click();
    }

    @Then("user clicks on sign in button")
    public void user_clicks_on_sign_in_button() {
        WebElement signInBtn = driver.findElement(By.id("submit"));
        signInBtn.click();
    }
    @Then("user validates Welcome message land on Home Page")
    public void user_validates_welcome_message_land_on_home_page() {
        WebElement welcomeMessage = driver.findElement(By.xpath("//li[@class='active']"));
        Assertions.assertEquals("Welcome Alaa",welcomeMessage.getText());
    }

    @Then("user enters {string} username")
    public void user_enters_username(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }

    @Then("user enters {string} password")
    public void user_enters_password(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }


    @Then("user validates {string} error message")
    public void user_validates_error_message(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }


    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
